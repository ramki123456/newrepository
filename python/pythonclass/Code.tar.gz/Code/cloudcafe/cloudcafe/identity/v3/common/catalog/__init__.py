from cloudcafe.identity.v3.common.catalog.client import CatalogClient
client = CatalogClient
