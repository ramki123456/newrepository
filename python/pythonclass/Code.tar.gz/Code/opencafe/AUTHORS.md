Original Authors
----------------
Sam Danes
Jose Idar
Brandon Logan
Carlos Martinez
Daryl Walleck

Contributors
------------
Anna Eilering
Richard Hawkins
Christopher Hunt
Michael Jackson
Melissa Kam
Malini Kamalambal
Stephen Lowrie
Leonardo Maycotte
Franklin Naval
Ivo Vasev
John Vrbanac
Eli Uriegas
Marcus Medley
Jason Meridth
