======================
OpenCAFE Documentation
======================

.. toctree::

.. toctree::
   :maxdepth: 4

   cafe


Index
==================

* :ref:`genindex`